package dailycost.com.dailycost.view;

import java.util.List;
import java.util.Map;

import dailycost.com.dailycost.model.Expense;

public interface CurrentWeekExpenseView {
  void displayCurrentWeeksExpenses(Map<String, List<Expense>> expensesByDate);

  void displayTotalExpenses(Long totalExpense);
}
