package dailycost.com.dailycost.presenter;

import dailycost.com.dailycost.database.ExpenseDatabaseHelper;
import dailycost.com.dailycost.utils.ExpenseCollection;
import dailycost.com.dailycost.view.CurrentWeekExpenseView;

public class CurrentWeekExpensePresenter {

  private CurrentWeekExpenseView view;
  private ExpenseDatabaseHelper database;
  private ExpenseCollection expenseCollection;

  public CurrentWeekExpensePresenter(ExpenseDatabaseHelper database, CurrentWeekExpenseView view) {
    this.database = database;
    this.view = view;
    expenseCollection = new ExpenseCollection(this.database.getCurrentWeeksExpenses());
  }

  public void renderTotalExpenses() {
    view.displayTotalExpenses(expenseCollection.getTotalExpense());
  }

  public void renderCurrentWeeksExpenses() {
    view.displayCurrentWeeksExpenses(expenseCollection.groupByDate());
  }
}
