package dailycost.com.dailycost.view;

public interface AddCategoryView {
  String getCategory();

  void displayError();
}
