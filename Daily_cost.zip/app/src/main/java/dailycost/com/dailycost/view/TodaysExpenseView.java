package dailycost.com.dailycost.view;

import java.util.List;

import dailycost.com.dailycost.model.Expense;

public interface TodaysExpenseView {
  void displayTotalExpense(Long totalExpense);
  void displayTodaysExpenses(List<Expense> expenses);
}
