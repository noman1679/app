package dailycost.com.dailycost.model;

public class ExpenseType {
  private String type;

  public ExpenseType(String type) {
    this.type = type;
  }

  public String getType() {
    return type;
  }
}
